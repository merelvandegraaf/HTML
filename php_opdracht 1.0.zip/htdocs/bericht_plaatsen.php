<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <title>Bericht maken</title>
    <link rel="stylesheet" href="CSS/styles.css"/>
    <meta name="description" content="Beroepsproduct website over voetbal">
    <meta name="keywords" content="Voetbal">
    <meta name="author" content="Brian van der Wiel & Merel van de Graaf">
</head>
<body>
<?php
include("php/header.php");
?>
<main>
   <h2>Plaats een bericht</h2>
    <form>
        Post naam<br>
        <input type="text" name="Onderwerp"><br>

        Onderwerp<br>
        <select name="Onderwerp">
            <option value="regels">Regels</option>
            <option value="spelers">Spelers</option>
            <option value="clubs">Clubs</option>
            <option value="kampioenschappen">Kampioenschappen</option>
            <option value="strategie">Strategie</option>
            <option value="trainingen">Trainingen</option>
        </select><br>

        Bericht<br>
        <textarea name="subject" placeholder="Je bericht.."></textarea><br>

        <input type="submit" value="Submit">
        <input type="reset" value="Reset">
    </form>
</main>
<?php
include("php/footer.php");
?>
</body>
</html>