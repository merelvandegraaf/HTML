<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <title>Bezoeker inloggen</title>
    <link rel="stylesheet" href="CSS/styles.css"/>
    <meta name="description" content="Beroepsproduct website over voetbal">
    <meta name="keywords" content="Voetbal">
    <meta name="author" content="Brian van der Wiel & Merel van de Graaf">
</head>
<body>
<?php
include("php/header.php");
?>
<main>
    <h2>Inloggen</h2>
    <form>
        Gebruikersnaam:<br>
        <input type="text" name="username"><br>
        Wachtwoord:<br>
        <input type="password" name="psw">
        <input type="submit" value="Submit">
    </form>
    <p>Geen account? Klik <a href="account_aanmaken.php">hier</a> om er een aan te maken</p>
</main>
<?php
include("php/footer.php");
?>
</body>
</html>