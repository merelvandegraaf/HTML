<?php

require ("php/registreren.php");

?>

<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <title>Account aanmaken</title>
    <link rel="stylesheet" href="CSS/styles.css"/>
    <meta name="description" content="Beroepsproduct website over voetbal">
    <meta name="keywords" content="Voetbal">
    <meta name="author" content="Brian van der Wiel & Merel van de Graaf">
</head>
<body>
<?php
include("php/header.php");
?>
<main>
    <h2>Registeren</h2>
    <div class="registreren">
    <form method="post"  action="account_aanmaken.php">
        <?php if(isset($smsg)){ ?><div role="alert"> <?php echo $smsg; ?> </div><?php } ?>
        <?php if(isset($fmsg)){ ?><div role="alert"> <?php echo $fmsg; ?> </div><?php } ?>
        <label>Gebruikersnaam</label>
        <input type="text"  name="gebruikersnaam"  placeholder="Gebruikersnaam" required>

        <label>Naam</label>
        <input type="text" name="naam"  placeholder="Naam" required>

        <label>Wachtwoord</label>
        <input type="password" name="wachtwoord" placeholder="Wachtwoord" required>

        <label>Wachtwoordbevestiging</label>
        <input type="password" name="wachtwoordbevestiging" placeholder="Nogmaals je wachtwoord" required>

        <input type="submit" name="verzenden" value="Submit">
        <input type="reset" value="Reset">
    </form>
    </div>
</main>
<?php
include("php/footer.php");
?>
</body>
</html>