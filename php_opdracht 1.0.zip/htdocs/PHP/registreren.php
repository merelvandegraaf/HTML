<?php
	require_once('config.php');


	if (isset($_POST['gebruikersnaam']) && isset($_POST['wachtwoord'])){

        if($_POST['wachtwoord'] == $_POST['wachtwoordbevestiging']) {

            $username = $_POST['gebruikersnaam'];
            $naam = $_POST['naam'];
            $password = $_POST['wachtwoord'];
            $cpassword = $_POST['wachtwoordbevestiging'];

            $query = "INSERT INTO `bezoekers` (login, naam, wachtwoord) VALUES ('$username', '$naam', '$password')";
            $result = mysqli_query($connectie, $query);
            if ($result) {
                $smsg = "<b>Gebruiker succesvol aangemaakt! Log meteen in!</b>";
            } else {
                $fmsg = "<b>Er is iets misgegaan...</b>";
            }
        }

        else if($_POST['wachtwoord'] != $_POST['wachtwoordbevestiging']){
            $smsg = "<b>Wachtwoorden matchen niet met elkaar. Vul het formulier deze opnieuw in</b><br>";
        }


    }
    ?>


