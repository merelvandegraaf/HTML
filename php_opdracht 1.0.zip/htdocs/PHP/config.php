<?php
define('DB_SERVER', 'www.mojiweb.nl');
define('DB_GEBRUIKERSNAAM', 'u22204p16853_bvdw');
define('DB_WACHTWOORD', 'sGKRKyTM0');
define('DB_DATABASE', 'u22204p16853_bvdw');
$connectie = mysqli_connect(DB_SERVER,DB_GEBRUIKERSNAAM,DB_WACHTWOORD,DB_DATABASE);
session_start();



