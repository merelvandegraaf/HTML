<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <title>Forum</title>
    <link rel="stylesheet" href="CSS/styles.css"/>
    <meta name="description" content="Beroepsproduct website over voetbal">
    <meta name="keywords" content="Voetbal">
    <meta name="author" content="Brian van der Wiel & Merel van de Graaf">
</head>
<body>
<?php
include("php/header.php");
?>
<main>
    Zoek op titel:<input type="search"><br>
    <table>
        <tr>
            <th>Onderwerpen</th>
            <th>Posts</th>
            <th>Laatst gepost</th>
        </tr>
        <tr>
            <td><a href="voorbeeld_forum.php">Regels</a></td>
            <td>17</td>
            <td>Gisteren</td>
        </tr>
        <tr>
            <td><a href="Spelers.html">Spelers</a></td>
            <td>50</td>
            <td>2 dagen geleden</td>
        </tr>
        <tr>
            <td><a href="Clubs.html">Clubs</a></td>
            <td>30</td>
            <td>Gisteren</td>
        </tr>
        <tr>
            <td><a href="Kampioenschappen.html">Kampioenschappen</a></td>
            <td>60</td>
            <td>4 dagen geleden</td>
        </tr>
        <tr>
            <td><a href="Strategie.html">Strategie</a></td>
            <td>8</td>
            <td>1 week geleden</td>
        </tr>
        <tr>
            <td><a href="Trainingen.html">Trainingen</a></td>
            <td>19</td>
            <td>5 dagen geleden</td>
        </tr>
    </table>

    <a id="berichtplaatsen" href="bericht_plaatsen.php">Maak een bericht aan</a>
</main>
<?php
include("php/footer.php");
?>
</body>
</html>