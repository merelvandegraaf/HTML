<?php
session_start();
if(isset($_POST['inloggen'])) {
    include_once("config.php");

    $user = ($_POST['username']);
    $password = ($_POST['password']);
    $result = mysqli_query($connectie, "SELECT * FROM bezoekers WHERE login = '$user'");


    if ($result->num_rows == 0) {
        $_SESSION['message'] = "Dit account is niet bekend";
        echo "Dit account is niet bekend";
    } else {
        $user = $result->fetch_assoc();

        //print_r($user); die;

        if ($_POST['password'] == $user['wachtwoord']) {

            $_SESSION['user'] = $user['wachtwoord'];
            $_SESSION['naam'] = $user['naam'];
            $_SESSION['logged_in'] = true;

            $message = print_r($_SESSION);
            header('Location: ../index.php');


        } else {
            $_SESSION['message'] = "Het wachtwoord is onjuist";
            echo "Het wachtwoord is onjuist";
        }
    }
}

else {
        header("index.php");
        exit;
    }



    
    
                                    

