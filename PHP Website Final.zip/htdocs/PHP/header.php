<header>
    <?php
    session_start();
    ?>
    <img id="logo" src="Afbeeldingen/logo.png" alt="logo" style="border:0;"><h1>Voetbal</h1>
    <nav>
        <a  href="index.php">Home</a>
        <div class="dropdown">
            <button class="dropbtn">Video's</button>
            <div class="dropdown-content">
                <a href="videos.php">Hoofdpagina</a>
                <a href="#">Video 1</a>
                <a href="#">Video 2</a>
                <a href="#">Video 3</a>
                <a href="#">Video 4</a>
            </div>
        </div>

        <div class="dropdown">
            <button  class="dropbtn">Forum</button>
            <div class="dropdown-content">
                <a href="forum.php">Forum</a>
                <a href="voorbeeld_forum.php">Regels</a>
                <a href="#">Spelers</a>
                <a href="#">Clubs</a>
                <a href="#">Kampioenschappen</a>
                <a href="#">Strategie</a>
                <a href="#">Trainingen</a>
            </div>
        </div>

        <a href="over_ons.php">Over ons</a>
        <?php

        if (isset($_SESSION['logged_in'])) {
            if ($_SESSION['logged_in'] == true) {
                $menu_titel = $_SESSION['naam'];
                echo '<div class="dropdown">
                    <button class="dropbtn">' . $_SESSION['naam'] . '</button>
                    <div class="dropdown-content">
                        <a href="php/logout.php"> Uitloggen</a>
                    </div>
                  </div>';
            }
        }
        else{
        $menu_titel = 'Bezoeker';
            echo '<a href="bezoeker.php">Bezoeker</a>';
        }


        ?>
    </nav>
</header>