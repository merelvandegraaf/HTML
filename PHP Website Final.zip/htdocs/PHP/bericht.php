<?php
require_once('config.php');

if(isset($_POST['postnaam']) && isset($_POST['rubriek']) && isset($_POST['bericht'])) {

    $postnaam = $_POST['postnaam'];
    $rubriek = $_POST['rubriek'];
    $bericht = $_POST['bericht'];
    $naam = $_SESSION['naam'];


    $query1 = "INSERT INTO `posts` (kopje, tekst, bezoeker, rubriek ) VALUES ('$postnaam', '$bericht', '$naam', '$rubriek')";
    $result1 = mysqli_query($connectie, $query1);

    if ($result1) {
        header('bezoeker.php');
        $smsg1 = "<b>De post is succesvol geupload!</b>";
    } else {
        $fmsg1 = "<b>Er is iets misgegaan...</b>";
    }

}
else
    echo "Er is iets fout gegaan!";
