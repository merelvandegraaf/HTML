<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <title>Bezoeker inloggen</title>
    <link rel="stylesheet" href="CSS/styles.css"/>
    <meta name="description" content="Beroepsproduct website over voetbal">
    <meta name="keywords" content="Voetbal">
    <meta name="author" content="Brian van der Wiel & Merel van de Graaf">
</head>
<body>
<?php
include("php/header.php");
if (isset($_SESSION['logged_in'])) {
    if ($_SESSION['logged_in']) header("Location: index.php");
};
?>
<main>
    <h2>Inloggen</h2>
    <?php if(isset($smsg)){ ?><div role="alert"> <?php echo $smsg; ?> </div><?php } ?>
    <?php if(isset($fmsg)){ ?><div role="alert"> <?php echo $fmsg; ?> </div><?php } ?>
    <form action="PHP/login.php" method="post">
        Gebruikersnaam:<br>
        <input type="text" name="username"><br>
        Wachtwoord:<br>
        <input type="password" name="password">
        <input type="submit" name="inloggen" value="Submit">
    </form>
    <p>Geen account? Klik <a href="account_aanmaken.php">hier</a> om er een aan te maken</p>
</main>
<?php
include("php/footer.php");
?>
</body>
</html>