<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <title>Forum - Regels</title>
    <link rel="stylesheet" href="CSS/styles.css"/>
    <meta name="description" content="Beroepsproduct website over voetbal">
    <meta name="keywords" content="Voetbal">
    <meta name="author" content="Brian van der Wiel & Merel van de Graaf">
</head>
<body>
<?php
include("php/header.php");
?>
<main>
    <h2>Regels</h2>
    <div class="forum">
        <div class="onderwerp">Gele kaarten</div>
        Borrussia_DortmundFan <br>
        <div class="datum">Gepost op: 27 november</div> <br>
        <br>
        Ik vind dat er veel te snel gele kaarten worden gegeven voor kleine overtredingen<br>
        <br>
        XXXAjaxXXX<br>
        <div class="datum">Gepost op: 28 november</div> <br>
        Ik vind dat de gele kaarten terecht zijn en er eerlijker gespeeld moet worden.
    </div>
    <br>
    <div class="forum">
        <div class="onderwerp">Schwalbe</div>
        MessiFan<br>
        <div class="datum">Gepost op: 22 november</div> <br>
        <br>
        Ik vind dat er te veel schwalbes gemaakt worden en er weer eerlijk gespeeld wordt in plaats van dat er een toneelstuk gespeeld wordt.<br>
        <br>
        Schalke_04_<br>
        <div class="datum">Gepost op: 22 november</div> <br>
        Ik vind dat er ook minder schwalbes gemaakt moeten worden want zo kan de scheidsrechter beter beslissen of er een straf moet komen of niet.
    </div>
</main>
<?php
include("php/footer.php");
?>
</body>
</html>